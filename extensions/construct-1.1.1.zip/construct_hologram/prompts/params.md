# The simple path: a parameter document

Fill this document for the object; a builder draws it. Choose the archetype and variant
that match, copy the user's facts with their certainty, and leave `params` empty unless the
user gave sizes (then give them in metres and say how certain they are in `param_certainty`).

```json
{
  "format": "construct-params",
  "version": 1,
  "archetype": "book",
  "variant": "paperback",
  "id": "my-paperback",
  "title": "Replace with the item's name",
  "synthetic": false,
  "facts": [
    {
      "key": "title",
      "value": "replace or delete",
      "certainty": "user_supplied",
      "source": "request"
    },
    {
      "key": "author",
      "value": "replace or delete",
      "certainty": "user_supplied",
      "source": "request"
    }
  ],
  "artwork": {},
  "params": {}
}
```

Archetypes, variants, standard sizes and artwork slots:

- case / jewel (standard CD jewel case): width=0.142, height=0.125, depth=0.0104; slots: cover-front, inlay, disc
- case / slim (standard slim CD case): width=0.142, height=0.125, depth=0.0052; slots: cover-front, cover-back, disc
- case / digipak (typical two-panel digipak): width=0.1395, height=0.125, depth=0.008; slots: cover-front, cover-back, inlay, disc
- case / box (a slipcase of slim cases): width=0.145, height=0.13, discs=3; slots: cover-front, cover-back
- book / hardcover (a common trade hardcover): width=0.156, height=0.234, thickness=0.036; slots: cover-front, cover-back
- book / paperback (a common mass-market paperback): width=0.129, height=0.198, thickness=0.025; slots: cover-front, cover-back
- object / electric-guitar (a solid-body electric guitar): body_style=double-cut, scale_length=0.648, strings=6, frets=22, pickups=3, knobs=3
- object / acoustic-guitar (a dreadnought acoustic guitar): scale_length=0.645, strings=6, frets=20
- object / bass-guitar (a solid-body electric bass): scale_length=0.864, strings=4, frets=20, pickups=2, knobs=3
- object / synth (a keyboard synthesizer): keys=49, knob_rows=2, knobs_per_row=8, screen=true, wheels=true
- vehicle / wedge (a mid-engined wedge supercar): length=4.14, width=1.89, height=1.07, wheelbase=2.45, wheel_diameter=0.64
- vehicle / coupe (a front-engined grand-touring coupe): length=4.57, width=1.68, height=1.34, wheelbase=2.49, wheel_diameter=0.7
- vehicle / sedan (a four-door sedan): length=4.8, width=1.83, height=1.45, wheelbase=2.85, wheel_diameter=0.68
- vessel / bottle (a 330 ml long-neck bottle): height=0.235, diameter=0.061; slots: label
- vessel / can (a 330 ml can): height=0.115, diameter=0.066; slots: label
- vessel / glass (a pint glass): glass_style=pint, height=0.15, diameter=0.086, fill=0.85
Parameters: width (outer width, metres, 0.02..3); height (outer height, metres, 0.02..3); depth (outer depth (thickness) closed, metres, 0.002..1); thickness (thickness of the closed book, metres, 0.003..0.2); diameter (widest diameter, metres, 0.02..0.5); discs (number of discs, 1..12); scale_length (nut-to-bridge string length, metres, 0.4..1); strings (number of strings, 4..12); frets (number of frets, 12..27); pickups (number of pickups, 0..3); knobs (number of control knobs, 0..6); keys (number of keys, 25..88); knob_rows (rows of knobs on the panel, 0..4); knobs_per_row (knobs in each row, 0..16); fill (how full the glass is, 0..1); length (overall length, metres, 1..12); wheelbase (front to rear axle, metres, 0.8..7); wheel_diameter (outer tyre diameter, metres, 0.3..1.5)
Choices: body_style: double-cut, single-cut, offset; glass_style: pint, tulip, stange; screen: true, false; wheels: true, false

Fact keys the builder sets as text when they exist: `title`, and the first of
`artist`, `author`, `creator`, `composer`, `brewery`, `maker` (the creator line); vessels
also `style`; guitars and synths `maker` and `model`. A missing fact simply has no line
(no author known: no author line). Other facts are kept as evidence:
use plain keys such as `year`, `label`, `publisher`, `abv` (with `"unit": "%"`), `volume`
(with `"unit": "ml"`), `discs`.

`params` stays empty (`{}`) unless the user gave a size or the item differs from the
standard: then give only what differs, in metres, and say in `param_certainty` whether the
user gave it (`user_supplied`) or you derived it (`inferred`). Common sizes: cans of 330 ml
are 0.115 m tall, 440 ml 0.147 m, 500 ml 0.168 m (all 0.066 m wide); a 500 ml bottle is
about 0.25 m tall; a hardcover is about 0.16 x 0.24 m, a mass-market paperback 0.11 x 0.18 m.
Leave out `sources`: a `request` source is added for you. Example of a stated size:
`"params": {"height": 0.147}, "param_certainty": {"height": "inferred"}` (a 440 ml can).
`"synthetic": false` for real requests; `true` only for examples and tests.

`artwork` maps a slot to the id of an asset in `assets` (only images the user supplied:
`{"id", "path", "sha256", "media_type", "rights", "provenance", "source"}`). Leave a slot out
when there is no image; the renderer shows its designed face.

A complete example (synthetic):

```json
{
  "format": "construct-params",
  "version": 1,
  "archetype": "case",
  "variant": "jewel",
  "id": "case-jewel",
  "title": "Example Album (jewel case)",
  "synthetic": true,
  "sources": [
    {
      "id": "request",
      "kind": "user_request",
      "title": "Synthetic example request",
      "rights": "synthetic"
    },
    {
      "id": "generated-art",
      "kind": "generated",
      "title": "Abstract pattern generated by the toolkit (png.py)",
      "rights": "synthetic"
    }
  ],
  "facts": [
    {
      "key": "title",
      "value": "Example Album",
      "certainty": "user_supplied",
      "source": "request",
      "note": "invented for this synthetic example"
    },
    {
      "key": "artist",
      "value": "Example Artist",
      "certainty": "user_supplied",
      "source": "request",
      "note": "invented for this synthetic example"
    }
  ],
  "assets": [
    {
      "id": "disc-art",
      "path": "assets/disc-cover.png",
      "sha256": "2a5f94b21f63a49eb49b7bc39b3c93bf1a2952267774ffee8ae1297f92fee8af",
      "media_type": "image/png",
      "rights": "synthetic",
      "provenance": "generated-decorative",
      "source": "generated-art"
    }
  ],
  "artwork": {
    "cover-front": "disc-art",
    "disc": "disc-art"
  }
}
```
