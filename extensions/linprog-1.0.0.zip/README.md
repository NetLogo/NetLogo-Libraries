# NetLogo linprog extension 
version 1.0 - July 2025 (for Netlogo v7)

The LinProg extension contains methods for solving linear programming problems.  

To install this extension, simply put `extensions [ linprog ]` as the first line of your model code or add `linprog` to the current extensions line and NetLogo's Extension Manager should install it.  

The documentation for the linprog extension is contained in the PDF file *linprog-1.0.pdf* and examples of its use are in the `Examples` directory. Both of these are in the linprog installation folder, which can generally be found in this subfolder relative to your home (user) directory:  
	On Mac OS X: `Library/Application Support/NetLogo`  
	On Windows: `AppData\Roaming\NetLogo\6.1\extensions`  
	On Linux: `.netlogo`

For more information, see https://ccl.northwestern.edu/netlogo/docs/extensions.html#where-extensions-are-located.

Java source files and a manifest are contained in the `src` directory. 

## Author

Charles Staelin<br>
Smith College<br>
Northampton, MA 01063

## Feedback? Bugs? Feature Requests?

Please visit the [github issue tracker](https://github.com/cstaelin/LinProg-Extension/issues?state=open) to submit comments, bug reports, or feature requests.  I'm also more than willing to accept pull requests.

## Credits

The linprog extension was written by Charles Staelin to allow the linear programming methods in the Apache commons-math library to be available to NetLogo. See the documentation for full credits.

## Terms of Use

[![CC0](http://i.creativecommons.org/p/zero/1.0/88x31.png)](http://creativecommons.org/publicdomain/zero/1.0/)

The NetLogo linprog extension is in the public domain.  To the extent possible under law, Charles Staelin has waived all copyright and related or neighboring rights.  However, note that the external libraries may be subject to other license terms. For more information please refer to the `licence.md` file accompanying this release.
