package org.nlogo.extensions.linprog;
/*
              LinProg - TO BE USED WITH NETLOGO v7.0
*/ 

 /*
  * LinProg contains the linear programming methods formerly contained in
  * versions of the numanal extension prior to version 4.0.
  * 
  * This extension assumes that functions can be passed to it in the form 
  * of NetLogo anonymous reporters and therefore works only with NetLogo 
  * versions 6.0 and above.  
  *
  * The Apache commons-math3 library is to actually solve the linear 
  * programming problems.  commons-math3.3.6.1.jar, 
  * distributed with this package, must be placed 
  * in the same directory as the linprog.jar file. The licenses for the use
  * of this package is found in the the license.md file distributed
  * with this extension.
  *
  * In addition, netlogo-7.x.x.jar (where the x's are the subversion 
  * numbers of the current NetLogo extension) and scala-library-2.13.16.jar 
  * are also required. These jar files are found in the /app subdirectory 
  * of the NetLogo instalation.\
 */

public class LinProgExtension extends org.nlogo.api.DefaultClassManager {

  // Define the primitives.
  @Override
  public void load(org.nlogo.api.PrimitiveManager primManager) {
    primManager.addPrimitive("LPsimplex",
            new ApacheLPSolve.LPSimplexSolve(ApacheLPSolve.SOLVE_PRIMAL));
    primManager.addPrimitive("LPdualsimplex",
            new ApacheLPSolve.LPSimplexSolve(ApacheLPSolve.SOLVE_DUAL));
  }
}
