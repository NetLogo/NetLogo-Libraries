package org.nlogo.extensions.linprog;

import org.nlogo.api.LogoException;
import org.nlogo.api.ExtensionException;
import org.nlogo.api.Context;
import org.nlogo.core.LogoList;
import org.nlogo.api.LogoListBuilder;

/**
 This class is package-private by default.
 */
class LinProgUtils {

  public static void writeToNetLogo(String mssg, Boolean toOutputArea, 
          Context context) throws ExtensionException {
    try {
      context.workspace().outputObject(mssg, null, true, true, 
              (toOutputArea) ? 
                      org.nlogo.api.OutputDestinationJ.OUTPUT_AREA() : 
                      org.nlogo.api.OutputDestinationJ.NORMAL());
    } catch (LogoException e) {
      throw new ExtensionException(e);
    }
  }

  public static double[][] convertNestedLogoListToArray(LogoList nestedLogoList) 
          throws ExtensionException {
    int numRows = nestedLogoList.size();
    if (numRows == 0) {
      throw new ExtensionException("input list was empty");
    }
    int numCols = -1;
    // find out the maximum column size of any of the rows,
    // in case we have a "ragged" right edge, where some rows
    // have more columns than others.
    for (Object obj : nestedLogoList.toJava()) {
      if (obj instanceof LogoList) {
        LogoList rowList = (LogoList) obj;
        if (numCols == -1) {
          numCols = rowList.size();
        } else if (numCols != rowList.size()) {
          throw new ExtensionException("To convert a nested list "
                  + "into a matrix, all nested lists must be the "
                  + "same length -- e.g. [[1 2 3 4] [1 2 3]] is "
                  + "invalid, because row 1 has one more entry.");
        }
      } else {
        throw new ExtensionException("To convert a nested list into "
                + "a matrix, there must be exactly two levels of "
                + "nesting -- e.g. [[1 2 3] [4 5 6]] creates a good "
                + "2x3 matrix.");
      }
    }
    if (numCols == 0) {
      throw new ExtensionException("input list contained only empty lists");
    }
    double[][] array = new double[numRows][numCols];
    int row = 0;
    for (Object obj : nestedLogoList.toJava()) {
      int col = 0;
      LogoList rowList = (LogoList) obj;
      for (Object obj2 : rowList.toJava()) {
        if (obj2 instanceof Number) {
          array[row][col] = ((Number) obj2).doubleValue();
          col++;
        } else {
          throw new ExtensionException("input list contains a non-number");
        }
      }
//      This should be unnecessary since we've checked to see that all 
//      columns are of equal length and only contain numbers.
//      // pad with zeros if we have a "ragged" right edge
//      for (; col < numCols; col++) {
//        array[row][col] = 0.0;
//      }
      row++;
    }
    return array;
  }
   
   public static LogoList convertArrayToNestedLogoList(double[][] dArray) {
    LogoListBuilder lst = new LogoListBuilder();
    for (double[] row : dArray) {
      LogoListBuilder rowLst = new LogoListBuilder();
      for (double elem : row) {
        rowLst.add(elem);
      }
      lst.add(rowLst.toLogoList());
    }
    return lst.toLogoList();
  }
  public static double[] convertSimpleLogoListToArray(LogoList xlist) {
    int n = xlist.size();
    double[] x = new double[n];
    for (int j = 0; j < n; j++) {
      x[j] = ((Number) xlist.get(j)).doubleValue();
    }
    return x;
  }
  
public static int[] convertSimpleLogoListToIntArray(LogoList xlist) {
    int n = xlist.size();
    int[] x = new int[n];
    for (int j = 0; j < n; j++) {
      x[j] = ((Number) xlist.get(j)).intValue();
    }
    return x;
  }

public static boolean[] convertSimpleLogoListToBooleanArray(LogoList xlist) {
    int n = xlist.size();
    boolean[] x = new boolean[n];
    for (int j = 0; j < n; j++) {
      x[j] = (Boolean) xlist.get(j);
    }
    return x;
  }

  public static LogoList convertArrayToSimpleLogoList(double[] x) {
    LogoListBuilder xlist = new LogoListBuilder();
    for (double elem : x) {
      xlist.add(elem);
    }
    return xlist.toLogoList();
  }

  public static void printValue(String lbl, double val, Context context) 
          throws ExtensionException, LogoException {
    LinProgUtils.writeToNetLogo(lbl + " " + val, false, context);
  }
  
  public static void printBoolean(String lbl, boolean val, Context context) 
          throws ExtensionException, LogoException {
    LinProgUtils.writeToNetLogo(lbl + " " + val, false, context);
  }
 
  public static void printInt(String lbl, int val, Context context) 
          throws ExtensionException, LogoException {
    LinProgUtils.writeToNetLogo(lbl + " " + val, false, context);
  }
  
    public static void printString(String strng, Context context) {
        try {
            LinProgUtils.writeToNetLogo(strng, false, context);
        } catch (ExtensionException e) {}
    }
  
  public static void printArray(String lbl, double[] vec, Context context)
          throws ExtensionException, LogoException {
      int n = vec.length;
      StringBuilder buf = new StringBuilder();
      for (int j = 0; j < n; j++) {
          buf.append(vec[j]);
          buf.append(" ");
      }
      LinProgUtils.writeToNetLogo(lbl + " " + buf.toString(), false, context);
  }
}