# README

This extension allows you to easily connect **NetLogo** to a large language model (LLM).
The example shows the complete lifecycle of an LLM instance: setup, configuration, interaction, inspection, and cleanup.

---

## Requirements

NetLogo version 7.0.

---

## Example Overview

The provided code:

- creates an LLM instance with the ID `model-A`
- configures model parameters (temperature, context window)
- defines a system prompt (assistant role)
- sends a user query to the model
- displays the model response
- prints instance metadata and message history
- properly destroys the instance

---

## Example Code for Ollama local run

```netlogo
extensions [llm-chat]

to setup
  llm-chat:setup-required "model-A" "llama3.1" "ollama" "http://localhost:11434"

  llm-chat:setup-additional "model-A" (list "" 0.7 20)

  llm-chat:init "model-A"

  llm-chat:system-message "model-A" "You are an assistant who helps with programming agent simulations in NetLogo."

  show llm-chat:chat "model-A" "What is the command to create a turtle?"

  show llm-chat:get-info "model-A"

  llm-chat:get-message-hisory "model-A"

  llm-chat:destroy "model-A"
  show llm-chat:get-info "model-A"
end
```

---

## Step-by-Step Explanation

### 1. Load the Extension

```netlogo
extensions [llm-chat]
```

Makes all llm-chat primitives available in the model.

---

### 2. Required Setup

```netlogo
llm-chat:setup-required "model-A" "llama3.1" "ollama" "http://localhost:11434"
```

- **modelA** – unique instance identifier
- **llama3.1** – model name
- **ollama** – backend type ollama/openai
- **URL** – LLM url

---

### 3. Additional Parameters

```netlogo
llm-chat:setup-additional "model-A" (list "" 0.7 20)
```

- **API key** - API key (empty; Ollama does not require one)
- **temperature** – controls response creativity
- **message window** – number of messages kept in context

---

### 4. Initialize the Instance

```netlogo
llm-chat:init "model-A"
```

Creates and initializes the LLM instance.

---

### 5. System Message

```netlogo
llm-chat:system-message "model-A" "You are an assistant who helps with programming agent simulations in NetLogo."
```

Defines the assistant’s role and behavior for the entire conversation.

---

### 6. Chat with the Model

```netlogo
show llm-chat:chat "model-A" "What is the command to create a turtle?"
```

- Sends a user prompt
- Returns the model’s textual response

---

### 7. Instance Information

```netlogo
show llm-chat:get-info "model-A"
```

Returns technical metadata about the instance (model, backend, parameters).

---

### 8. Message History

```netlogo
llm-chat:get-message-hisory "model-A"
```

Outputs the full conversation history, including:
- SYSTEM messages
- USER prompts
- AI responses

---

### 9. Destroy the Instance

```netlogo
llm-chat:destroy "model-A"
```

Releases resources and removes the instance from memory.

---

## Notes

- A single NetLogo model can manage multiple LLM instances using different IDs
- Always destroy instances when they are no longer needed
- The extension is well suited for:
  - assisted programming
  - agent behavior generation
  - experiments with LLM-driven simulations

---

## License

This example is free to use for educational and experimental purposes.

