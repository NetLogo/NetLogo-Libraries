# README

This extension allows you to easily connect **NetLogo** to a large language model (LLM).
The example shows the complete lifecycle of an LLM instance: setup, configuration, interaction, inspection, and cleanup.

---

## Requirements

NetLogo version 7.0.

---

## Example Overview

The provided code:

- creates an LLM instance with the ID `modelA`
- configures model parameters (temperature, context window)
- defines a system prompt (assistant role)
- sends a user query to the model
- displays the model response
- prints instance metadata and message history
- properly destroys the instance

---

## Example Code for Ollama local run

```netlogo
extensions [LLMChat]

to setup
  LLMChat:setupRequired "modelA" "llama3.1" "ollama" "http://localhost:11434"

  LLMChat:setupAdditional "modelA" (list "" 0.7 20)

  LLMChat:init "modelA"

  LLMChat:systemMessage "modelA" "You are an assistant who helps with programming agent simulations in NetLogo."

  show LLMChat:chat "modelA" "What is the command to create a turtle?"

  show LLMChat:getInfo "modelA"

  LLMChat:getMessageHisory "modelA"

  LLMChat:destroy "modelA"
  show LLMChat:getInfo "modelA"
end
```

---

## Step-by-Step Explanation

### 1. Load the Extension

```netlogo
extensions [LLMChat]
```

Makes all LLMChat primitives available in the model.

---

### 2. Required Setup

```netlogo
LLMChat:setupRequired "modelA" "llama3.1" "ollama" "http://localhost:11434"
```

- **modelA** – unique instance identifier
- **llama3.1** – model name
- **ollama** – backend type ollama/openai
- **URL** – LLM url

---

### 3. Additional Parameters

```netlogo
LLMChat:setupAdditional "modelA" (list "" 0.7 20)
```

- **API key** - API key (empty; Ollama does not require one)
- **temperature** – controls response creativity
- **message window** – number of messages kept in context

---

### 4. Initialize the Instance

```netlogo
LLMChat:init "modelA"
```

Creates and initializes the LLM instance.

---

### 5. System Message

```netlogo
LLMChat:systemMessage "modelA" "You are an assistant who helps with programming agent simulations in NetLogo."
```

Defines the assistant’s role and behavior for the entire conversation.

---

### 6. Chat with the Model

```netlogo
show LLMChat:chat "modelA" "What is the command to create a turtle?"
```

- Sends a user prompt
- Returns the model’s textual response

---

### 7. Instance Information

```netlogo
show LLMChat:getInfo "modelA"
```

Returns technical metadata about the instance (model, backend, parameters).

---

### 8. Message History

```netlogo
LLMChat:getMessageHisory "modelA"
```

Outputs the full conversation history, including:
- SYSTEM messages
- USER prompts
- AI responses

---

### 9. Destroy the Instance

```netlogo
LLMChat:destroy "modelA"
```

Releases resources and removes the instance from memory.

---

## Notes

- A single NetLogo model can manage multiple LLM instances using different IDs
- Always destroy instances when they are no longer needed
- The extension is well suited for:
  - assisted programming
  - agent behavior generation
  - experiments with LLM-driven simulations

---

## License

This example is free to use for educational and experimental purposes.

