
**License Information**
**LPSolver v4.1**

The *lpsolver* extension is free software and you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, version 3 of the License, or (at your option) any later version. In the folder of source files, these are the classes contained in "lpsolver" sub-directory. This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY, without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

The *lpsolver* extension depends upon java classes and libraries available at https://sourceforge.net/projects/lpsolve/.  This is a package of free software made available under the GNU lesser general public license.  In the folder of source files, the java classes are those files that are contained in the "lpsolve" sub-directory.  Also part of the *lpsolve* package are native libraries written in C++ and bundled in sets of two libraries, one set for each platform.  They are distributed under the same license terms.


Should you desire a copy of the GNU General Public License, you can visit http://www.gnu.org/licenses/licenses.html, or write to the Free Software Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

The *lpsolver* extension was originally written by Adam MacKensie and has been heavily modified and updated by Charles Staelin for NetLogo 7.0 and JDK 17.