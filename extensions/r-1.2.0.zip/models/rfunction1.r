x <- function(x)
{
  n<-length(x)
  mittelwert<-prod(x)^(1/n)
  return (mittelwert)
}
