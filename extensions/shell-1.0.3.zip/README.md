# NetLogo shell extension

This package contains the NetLogo shell extension.

It lets you do things like:

> (Mac) `observer> show shell:exec "ls"`

> (Windows) `observer> show (shell:exec "cmd" "/c" "dir")`

The included commands are:

 * `shell:pwd` => reports current working directory
 * `shell:cd <directory>` => change current working directory (relative to current directory unless <directory> begins with a drive letter on Windows or a forward slash on Mac/Unix)
 * `shell:getenv <name>` => reports value of environment variable
 * `shell:setenv <name> <value>` => sets environment variable
 * `shell:exec <command> (shell:exec <command> <param> ...)` => execute command synchronously and report a string of the results it prints to stdout
 * `shell:fork <command> (shell:fork <command> <param> ...)` => execute command asynchronously and discard the results
 * `shell:reset` => clears any environment variables set  by `shell:setenv` and returns the working directory to the NetLogo model directory.

## Downloads

 * for NetLogo 7.0, 6.1: You can use [the extension manager](https://ccl.northwestern.edu/netlogo/docs/extension-manager.html) to install the Shell extension from within NetLogo.
 * for NetLogo 5.x: https://github.com/downloads/NetLogo/Shell-Extension/shell-5.0.zip
 * for NetLogo 4.1: https://github.com/downloads/NetLogo/Shell-Extension/shell-4.1.zip

## Using

The shell extension inherits all the environment variables that were in place when NetLogo was started. That makes `shell:getenv` very useful for passing the values of ennvironment variables on to NetLogo. HOWEVER, any environment variable set by `shell:setenv` is local to the shell extension only and will disappear when the NetLogo session is ended. Similarly, the working directory for the shell extension is initially set to the directory in which the NetLogo model is located. Changing the extension's working directory with `shell:cd` changes the working directory for the extension only. **It does not change the working directory for NetLogo itself.** That is done with NetLogo's `set-current-directory` command.

`shell:setenv` and `shell:cd` thus work only within the shell extension and are in the service of `shell:exec` and `shell:fork`, which do inherit their environment and working directory from the extension's.

## Installing

Check out [the extension manager](https://ccl.northwestern.edu/netlogo/docs/extension-manager.html) to install the Shell extension from within the NetLogo application.

For more information about NetLogo extensions in general, see the NetLogo User Manual.

## Building

Launch the project in SBT by running the `sbt` command (if you have it installed).  If you successfully run `package`, `shell.jar` is created.

## Credits

The shell extension was written by Eric Russell and updated to NetLogo 6.0 and then 6.1 by Charles Staelin.  Since 6.1, it has been maintained by the NetLogo development team.

## Terms of Use

[![CC0](http://i.creativecommons.org/p/zero/1.0/88x31.png)](http://creativecommons.org/publicdomain/zero/1.0/)

The NetLogo shell extension is in the public domain.  To the extent possible under law, Eric Russell has waived all copyright and related or neighboring rights.
