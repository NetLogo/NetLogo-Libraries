/*
 * Implements the reporters for placing the data table, the variance-
 * covariance matrix and the correlation matrix into strings for printing.
 */
package org.nlogo.extensions.stats;

import org.nlogo.api.*;
import org.nlogo.core.Syntax;
import org.nlogo.core.SyntaxJ;

public class PrintPrims {

    public static class ConvertDataToString implements Reporter {
        // Converts the data matrix to a string for printing. Rows and 
        // columns are labeled with the observation number and variable
        // names if the names have been defined.

        @Override
        public Syntax getSyntax() {
            return SyntaxJ.reporterSyntax(new int[]{Syntax.WildcardType()},
                    Syntax.StringType());
        }

        @Override
        public Object report(Argument args[], Context context)
                throws ExtensionException, LogoException {

            LogoStatsTbl tbl = StatsExtension.getTblFromArgument(args[0]);
            if (!tbl.haveData()) {
                throw new org.nlogo.api.ExtensionException(
                        "Attempt to print a data table "
                        + "before one has been created.");
            }
            return tbl.printData();
        }
    }

    /* ---------------------------------------------------------------------- */
    public static class ConvertCovarToString implements Reporter {
        // Converts the variance-covariance matrix to a string for printing.
        // Rows and columns are labeled with the variable names if they 
        // have been defined.

        @Override
        public Syntax getSyntax() {
            return SyntaxJ.reporterSyntax(new int[]{Syntax.WildcardType()},
                    Syntax.StringType());
        }

        @Override
        public Object report(Argument args[], Context context)
                throws ExtensionException, LogoException {

            LogoStatsTbl tbl = StatsExtension.getTblFromArgument(args[0]);
            String mat = tbl.printCovariance();
            if (mat == null) {
                throw new org.nlogo.api.ExtensionException(
                        "Attempt to print a variance-covariance matrix "
                        + "before one has been calculated.");
            }
            return mat;
        }
    }

    /* ---------------------------------------------------------------------- */
    public static class ConvertCorrelToString implements Reporter {
        // Converts the correlation matrix to a string for printing.
        // Rows and columns are labeled with the variable names if they 
        // have been defined.

        @Override
        public Syntax getSyntax() {
            return SyntaxJ.reporterSyntax(new int[]{Syntax.WildcardType()},
                    Syntax.StringType());
        }

        @Override
        public Object report(Argument args[], Context context)
                throws ExtensionException, LogoException {

            LogoStatsTbl tbl = StatsExtension.getTblFromArgument(args[0]);
            String mat = tbl.printCorrelation();
            if (mat == null) {
                throw new org.nlogo.api.ExtensionException(
                        "Attempt to print a correlation matrix "
                        + "before one has been calculated.");
            }
            return mat;
        }
    }
}