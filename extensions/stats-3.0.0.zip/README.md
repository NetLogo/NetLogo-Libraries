# NetLogo stats Extension - Version 3.0.0

* [What is it?](#what-is-it)
* [Installation](#Installation)
* [Examples](#examples)
* [Primitives](#primitives)
* [Author](#author)
* [Feedback](#feedback-bugs-feature-requests)
* [Credits](#credits)
* [Terms of use](#terms-of-use)

## What is it?

This package contains the NetLogo **stats extension**, which provides NetLogo with a tables for holding data gathered during runs, a number of statistical procedures to use on those data, and access to a number of useful distributions including the normal, students t, binomial, beta, gamma, and Chi squared distributions. Documentation of the features and use of the **stats extension** is found in the accompanying manual.  Java source files, a manifest and makefile for those who want examine the code or modify the extension for their own purposes are available at https://github.com/cstaelin/Stats-Extension/releases.

[back to top](#netlogo-stats-extension)

## Installation

To install this extension, simply put `extensions [ stats ]` as the first line of your model code (or add `stats` to the current extensions line) and NetLogo's Extension Manager should install it in the proper location.  

[http://ccl.northwestern.edu/netlogo/docs/extensions.html](http://ccl.northwestern.edu/netlogo/docs/extensions.html)

[back to top](#netlogo-stats-extension)


## Examples

See the **stats.nlogox** model for examples of usage.


[back to top](#netlogo-stats-extension)

## Primitives

Descriptions of all the stats primitives and their uses are contained in the accompanying manual.

[back to top](#netlogo-stats-extension)

## Author

Charles Staelin<br>
Smith College<br>
Northampton, MA 01063

## Feedback? Bugs? Feature Requests?

Please visit the [github issue tracker](https://github.com/cstaelin/Stats-Extension/issues?state=open) to submit comments, bug reports, or feature requests.  I'm also more than willing to accept pull requests.

## Credits

Many thanks to the NetLogo developers and the NetLogo user community for answering my questions and suggesting  additional features.

## Terms of Use

[![CC0](http://i.creativecommons.org/p/zero/1.0/88x31.png)](http://creativecommons.org/publicdomain/zero/1.0/)

The NetLogo stats extension is in the public domain.  To the extent possible under law, Charles Staelin has waived all copyright and related or neighboring rights. **However**, note that the external libraries may be subject to other license terms. For more information please refer to the `licence.md` file accompanying this release and to  <http://unlicense.org>.

[back to top](#netlogo-stats-extension)
